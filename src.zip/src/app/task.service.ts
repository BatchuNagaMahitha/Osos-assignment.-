import { Injectable } from '@angular/core';
@Injectable({ 
    providedIn: 'root' 
}) export class TaskService { 
    tasks: any[] = [ {id: 1, title: 'Hello World!'} ]; 
    constructor() { }
getTasks(){ 
        return this.tasks; 
    } 
    addTask(id:number, title:string){ 
        return this.tasks.push({id: id, title: title}); 
    } 
    deleteTask(id:number){ 
        let index = id-1; 
        if (index > -1) { 
            this.tasks.splice(index, 1); 
        } 
        return this.tasks; 
    } 
}